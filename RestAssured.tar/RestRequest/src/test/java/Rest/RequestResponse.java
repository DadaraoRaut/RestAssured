package Rest;

	import org.testng.Assert;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Test;
	import io.restassured.RestAssured;
	import io.restassured.config.RestAssuredConfig;
	import io.restassured.filter.log.RequestLoggingFilter;
	import io.restassured.filter.log.ResponseLoggingFilter;
	import io.restassured.response.Response;

	public class RequestResponse {
	    @BeforeClass
	    public static void setup() {
	        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
	        RestAssured.config = RestAssuredConfig.config().logConfig(
	                io.restassured.config.LogConfig.logConfig()
	                        .defaultStream(System.out)
	                        .enablePrettyPrinting(true)
	        );
	    }

	    @Test
	    public void testGetUserById() {
	        Response response = RestAssured
	                .given()
	                .filter(new RequestLoggingFilter())
	                .filter(new ResponseLoggingFilter())
	                .when()
	                .get("/users/1");
	        
	        Assert.assertEquals(response.getStatusCode(), 200);
	        Assert.assertEquals(response.jsonPath().get("id"), 1);
	    }

	    @Test
	    public void testGetPostsByUserId() {
	        Response response = RestAssured
	                .given()
	                .filter(new RequestLoggingFilter())
	                .filter(new ResponseLoggingFilter())
	                .when()
	                .get("/posts?userId=1");
	        
	        Assert.assertEquals(response.getStatusCode(), 200);
	        Assert.assertTrue(response.jsonPath().getList("$").size() > 0);
	    }
	}


